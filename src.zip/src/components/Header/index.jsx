import "./style.css";

export default function Header() {
    return <header>
        <img src="https://d9hhrg4mnvzow.cloudfront.net/templates.unbounce.com/mcgillis-university/f2976892-mcgillis-university-logo_07a01g07a01g000000001.png" />
        <p>Insert University Address  ◦  1.888.8888 </p>
    </header>



}