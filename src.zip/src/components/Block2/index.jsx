import "./style.css";

export default function Block2() {
    return <div className="Block2">

        <div className="div1">
            <span>1</span>
            <div className="div1p"> <p>Using 5% or more of your copy to evoke joy can increase your conversion rates.</p>
            </div> </div>
        <div className="div2">
            <span>2</span>
            <div className="div2p"> <p>Don’t stress about reading levels too much — just make sure you're explaining concepts clearly.</p>
            </div> </div>
        <div className="div3">
            <span>3</span>
            <div className="div3p"><p>On average, pages using 125 words or less have 15% higher conversion rates. (But between 250 and 750 words, there's very little difference.)

            </p> </div>
        </div>


    </div>

}