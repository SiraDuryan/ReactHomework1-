
import "./style.css";

export default function Block3() {
    return <div className="Block3">
        <div className="shadow"> </div>
        <div className="text">
            <h1>Give your reader some social proof with an authentic and awesome testimonial.</h1>
            <h3>Muhammed Riwan,  Grad 2017</h3>
        </div>
    </div>

}