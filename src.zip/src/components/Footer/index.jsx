import "./style.css";

export default function Footer() {
    return <footer>
        <p className="p1">Reinforcement copy of why this school is the best.</p>
        <img src="https://d9hhrg4mnvzow.cloudfront.net/templates.unbounce.com/mcgillis-university/b80b41f9-mcgillis-university-emblem_04e04e04e04e000000001.png" alt="" />
        <p className="p2">Insert University Address  ◦  Copyright © 2017 </p>


    </footer>

}