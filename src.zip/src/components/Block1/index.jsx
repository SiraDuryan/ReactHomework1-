import "./style.css";

export default function Block1() {
    return <div className="Block1">

        <div className="inputs">
    <h1>What's awesome about your university and why should they apply.</h1>

    <span>First Name*</span>
    <input type="text" />
    <span>Email*</span>
    <input type="email" />    
    <span>Phone Number *</span>
    <input type="number" />
    <button>APPLY TODAY</button>

        </div>


    </div>

}